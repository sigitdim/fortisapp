const express = require('express');
const router = express.Router();
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { persistSession: false } }
);

// Middleware: pastiin owner_id dikirim
function requireOwner(req, res, next) {
  const ownerId = req.headers["x-owner-id"];
  if (!ownerId) {
    return res.status(400).json({ ok: false, error: "x-owner-id required" });
  }
  req.owner_id = ownerId; // ✅ samain dengan yang dipakai di semua router lain
  next();
}


// === GET /setup/bahan ===
router.get("/bahan", requireOwner, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("bahan")
      .select("*")
      .eq("owner_id", req.owner_id)
      .order("created_at", { ascending: false });

    if (error) throw error;
    res.json({ ok: true, data });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * POST /setup/bahan
 * body: { nama, satuan, harga, stok_awal?, keterangan? }
 */
router.post('/bahan', requireOwner, async (req, res) => {
  const { nama, satuan, harga, stok_awal = 0, keterangan = null } = req.body || {};

  if (!nama || !satuan || typeof harga !== 'number') {
    return res.status(400).json({
      ok: false,
      error: 'Param wajib: nama(string), satuan(string), harga(number)',
    });
  }

const payload = {
  nama_bahan: nama,
  satuan,
  harga,
  owner_id: req.owner_id,

};

  const { data, error } = await supabase
    .from('bahan')
    .insert(payload)
    .select()
    .single();

  if (error)
    return res.status(500).json({ ok: false, error: error.message });

  res.status(201).json({ ok: true, data });
});

/**
 * GET /setup/overhead
 */
router.get('/overhead', requireOwner, async (req, res) => {
  const { data, error } = await supabase
    .from('overhead')
    .select('*')
    .eq('owner_id', req.owner_id)
    .order('created_at', { ascending: false });

  if (error) return res.status(500).json({ ok:false, error: error.message });
  res.json({ ok:true, count: data?.length || 0, data });
});

/**
 * POST /setup/overhead
 * body: { nama, biaya }
 */
router.post('/overhead', requireOwner, async (req, res) => {
  const { nama, biaya } = req.body || {};
  if (!nama || typeof biaya !== 'number') {
    return res.status(400).json({ ok:false, error:'Param wajib: nama(string), biaya(number)' });
  }

const payload = {
  nama_overhead: nama,
  biaya_bulanan: biaya,
  owner_id: req.owner_id
};

  const { data, error } = await supabase
    .from('overhead')
    .insert(payload)
    .select()
    .single();

  if (error) return res.status(500).json({ ok:false, error: error.message });
  res.status(201).json({ ok:true, data });
});

/**
 * GET /setup/tenaga_kerja
 */
router.get('/tenaga_kerja', requireOwner, async (req, res) => {
  const { data, error } = await supabase
    .from('tenaga_kerja')
    .select('*')
    .eq('owner_id', req.owner_id)
    .order('created_at', { ascending: false });

  if (error) return res.status(500).json({ ok:false, error: error.message });
  res.json({ ok:true, count: data?.length || 0, data });
});

/**
 * POST /setup/tenaga_kerja
 * body: { nama, gaji_bulanan }
 */
router.post('/tenaga_kerja', requireOwner, async (req, res) => {
  const { nama, jabatan = 'Operasional', gaji_bulanan } = req.body || {};
  if (!nama || typeof gaji_bulanan !== 'number') {
    return res.status(400).json({ ok:false, error:'Param wajib: nama(string), gaji_bulanan(number)' });
  }

  const payload = {
    nama,
    jabatan,
    gaji: gaji_bulanan,
    rate_type: 'per_bulan',
    rate_amount: gaji_bulanan,
    jam_kerja_per_hari: 8,
    hari_kerja_per_bulan: 26,
    owner_id: req.owner_id
  };

  const { data, error } = await supabase
    .from('tenaga_kerja')
    .insert(payload)
    .select()
    .single();

  if (error) return res.status(500).json({ ok:false, error: error.message });
  res.status(201).json({ ok:true, data });
});

// UPDATE overhead
router.put('/overhead/:id', requireOwner, async (req, res) => {
  const { id } = req.params;
  const { nama, biaya } = req.body || {};

  const payload = {};
  if (nama) payload.nama_overhead = nama;
  if (biaya !== undefined) payload.biaya_bulanan = biaya;

  const { data, error } = await supabase
    .from('overhead')
    .update(payload)
    .eq('id', id)
    .eq('owner_id', req.owner_id)
    .select(); // ← hapus .single()

  if (error) return res.status(500).json({ ok: false, error: error.message });
  res.json({ ok: true, data });
});

// DELETE overhead
router.delete('/overhead/:id', requireOwner, async (req, res) => {
  const { id } = req.params;

  const { data, error } = await supabase
    .from('overhead')
    .delete()
    .eq('id', id)
    .eq('owner_id', req.owner_id)
    .select()
    .single();

  if (error) return res.status(500).json({ ok:false, error:error.message });
  res.json({ ok:true, data });
});

// UPDATE tenaga_kerja
router.put('/tenaga_kerja/:id', requireOwner, async (req, res) => {
  const { id } = req.params;
  const { nama, jabatan, gaji_bulanan } = req.body || {};

  const payload = {};
  if (nama) payload.nama = String(nama).trim();
  if (jabatan !== undefined) payload.jabatan = String(jabatan || '').trim();
  if (gaji_bulanan !== undefined) {
    const n = Number(gaji_bulanan);
    if (Number.isNaN(n) || n < 0) return res.status(400).json({ ok:false, error:'gaji_bulanan harus angka >= 0' });
    payload.gaji = n;
    payload.rate_amount = n; // biar konsisten sama insert
  }

  const { data, error } = await supabase
    .from('tenaga_kerja')
    .update(payload)
    .eq('id', id)
    .eq('owner_id', req.owner_id)
    .select();

  if (error) return res.status(500).json({ ok:false, error:error.message });
  res.json({ ok:true, data });
});

// DELETE tenaga_kerja
router.delete('/tenaga_kerja/:id', requireOwner, async (req, res) => {
  const { id } = req.params;

  const { data, error } = await supabase
    .from('tenaga_kerja')
    .delete()
    .eq('id', id)
    .eq('owner_id', req.owner_id)
    .select();

  if (error) return res.status(500).json({ ok:false, error:error.message });
  res.json({ ok:true, data });
});

// UPDATE bahan
router.put('/bahan/:id', requireOwner, async (req, res) => {
  const { id } = req.params;
  const { nama, satuan, harga } = req.body || {};

  const payload = {};
  if (nama) payload.nama_bahan = String(nama).trim();
  if (satuan !== undefined) payload.satuan = String(satuan).trim();
  if (harga !== undefined) {
    const n = Number(harga);
    if (Number.isNaN(n) || n < 0) return res.status(400).json({ ok:false, error:'harga harus angka >= 0' });
    payload.harga = n;
  }

  const { data, error } = await supabase
    .from('bahan')
    .update(payload)
    .eq('id', id)
    .eq('owner_id', req.owner_id)
    .select();

  if (error) return res.status(500).json({ ok:false, error:error.message });
  res.json({ ok:true, data });
});

// DELETE bahan
router.delete('/bahan/:id', requireOwner, async (req, res) => {
  const { id } = req.params;

  const { data, error } = await supabase
    .from('bahan')
    .delete()
    .eq('id', id)
    .eq('owner_id', req.owner_id)
    .select();

  if (error) return res.status(500).json({ ok:false, error:error.message });
  res.json({ ok:true, data });
});

// === GET /setup/produk ===
router.get("/produk", requireOwner, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("produk")
      .select("id, nama_produk, kategori, harga_jual")
      .eq("owner_id", req.ownerId);

    if (error) throw error;
    res.json({ ok: true, data });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

module.exports = router;


