const express = require("express");
const { supabase } = require("../supabase.js");
const requireOwner = require("../middleware/requireOwner.js");

const router = express.Router();

// === GET semua komposisi per produk ===
router.get("/:produk_id", requireOwner, async (req, res) => {
  try {
    const { produk_id } = req.params;
    const { owner_id } = req;

const { data, error } = await supabase
  .from("komposisi")
  .select(`
    id,
    produk_id,
    bahan_id,
    qty,
    bahan:bahan_id (nama_bahan, satuan)
  `)
  .eq("produk_id", produk_id)
  .eq("owner_id", owner_id);


    if (error) throw error;
    res.json({ ok: true, data });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

// === POST tambah bahan ke produk ===
router.post("/", requireOwner, async (req, res) => {
  try {
    const { produk_id, bahan_id, qty } = req.body;
    const { owner_id } = req;

    if (!produk_id || !bahan_id || qty < 0)
      return res.status(400).json({ ok: false, error: "invalid input" });

    const { error } = await supabase.from("komposisi").insert({
      produk_id,
      bahan_id,
      qty,
      owner_id,
    });

    if (error) throw error;
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

// === PUT update qty bahan ===
router.put("/:id", requireOwner, async (req, res) => {
  try {
    const { id } = req.params;
    const { qty } = req.body;
    const { owner_id } = req;

    const { error } = await supabase
      .from("komposisi")
      .update({ qty })
      .eq("id", id)
      .eq("owner_id", owner_id);

    if (error) throw error;
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

// === DELETE bahan dari resep ===
router.delete("/:id", requireOwner, async (req, res) => {
  try {
    const { id } = req.params;
    const { owner_id } = req;

    const { error } = await supabase
      .from("komposisi")
      .delete()
      .eq("id", id)
      .eq("owner_id", owner_id);

    if (error) throw error;
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

module.exports = router;
